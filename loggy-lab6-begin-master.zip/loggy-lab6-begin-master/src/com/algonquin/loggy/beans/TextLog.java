package com.algonquin.loggy.beans;

public class TextLog extends Log {

    public TextLog() {
        super();
    }

    public TextLog(String title, String content) {
        super(title, content);
    }

}
